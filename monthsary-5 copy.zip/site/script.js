const $=id=>document.getElementById(id);
const P={a:'#5b3a99',b:'#b995f5',c:'#ff9fd0',d:'#ffe36e',e:'#7bd88f',f:'#fff',g:'#ff5fa8',k:'#2b1a4d',v:'#8a5fd6',w:'#6b44b0',p:'#f5e6c8',q:'#d9c49a'};
const M={
flower:['..c.c..','.ccdcc.','..cdc..','.c.e.c.','...e...','..ee...','...e...'],
heart:['.gg.gg.','ggggggg','ggggggg','.ggggg.','..ggg..','...g...'],
phone:['.aaaaa.','.afffa.','.afffa.','.afffa.','.afffa.','.aaaaa.','.a.b.a.'],
face:['..................','...aa........aa...','..aaaa......aaaa..','..aaaa......aaaa..','...aa........aa...','..cc..........cc..','..cc..........cc..','......a......a....','.......aaaaaa.....','........cccc......'],
book:['kkkkkkkkkkkkkk','kwwvvvvvvvvvvk','kwwvdvvvvvvdvk','kwwvvvvvvvvvvk','kwwvvggvggvvvk','kwwvgggggggvvk','kwwvgggggggvvk','kwwvvgggggvvvk','kwwvvvgggvvvvk','kwwvvvvgvvvvvk','kwwvvvvvvvvvvk','kwwvdvvvvvvdvk','kwwvvvvvvvvvvk','kppppppppppppk','kqqqqqqqqqqqqk','kkkkkkkkkkkkkk']};
function pix(n,s){const m=M[n];let r='';m.forEach((row,y)=>[...row].forEach((c,x)=>{if(c!='.')r+=`<rect x="${x}" y="${y}" width="1" height="1" fill="${P[c]}"/>`}));
return `<svg class="px" viewBox="0 0 ${m[0].length} ${m.length}" width="${m[0].length*s}" height="${m.length*s}">${r}</svg>`}
$('book').innerHTML=pix('book',9);
document.querySelectorAll('.ic').forEach(e=>e.innerHTML=pix(e.dataset.i,3));
for(let i=0;i<9;i++){const d=document.createElement('div');d.className='fl';d.style.left=(i*11+Math.random()*4)+'%';d.innerHTML=pix('flower',4+(i%3)*2);document.body.appendChild(d)}
function show(id){document.querySelectorAll('.pg').forEach(p=>p.classList.toggle('on',p.id==id));scrollTo(0,0)}
let code='';
for(let i=0;i<4;i++)$('dots').innerHTML+='<div class="dot"></div>';
['1','2','3','4','5','6','7','8','9','','0','⌫'].forEach(k=>{const b=document.createElement('button');if(k){b.textContent=k;b.onclick=()=>key(k)}else b.style.visibility='hidden';$('pad').appendChild(b)});
function key(k){
 if(k=='⌫')code=code.slice(0,-1);else if(code.length<4)code+=k;
 [...$('dots').children].forEach((d,i)=>d.classList.toggle('f',i<code.length));
 $('err').textContent='';
 if(code.length==4){setTimeout(()=>{
  if(code=='0409'){show('stats')}
  else{$('err').textContent='Riprova ♥';$('dots').classList.add('shake');setTimeout(()=>$('dots').classList.remove('shake'),400);code='';[...$('dots').children].forEach(d=>d.classList.remove('f'))}
 },200)}}
$('hint').onclick=()=>{$('hint').textContent='indizio: IL giorno ♥'};
document.addEventListener('keydown',e=>{if($('lock').classList.contains('on')){if(/^\d$/.test(e.key))key(e.key);if(e.key=='Backspace')key('⌫')}});
const start=new Date(2026,8,4,0,0,0),meet=new Date(2026,9,31,0,0,0);
function parts(ms){ms=Math.max(0,Math.floor(ms/1000));return{d:Math.floor(ms/86400),h:Math.floor(ms%86400/3600),m:Math.floor(ms%3600/60),s:ms%60}}
function fmt(a){return [['giorni',a.d],['ore',a.h],['min',a.m],['sec',a.s]].map(x=>`<b>${String(x[1]).padStart(2,'0')}</b><small>${x[0]}</small>`).join(' ')}
function tick(){const n=new Date();$('since').innerHTML=fmt(parts(n-start));$('until').innerHTML=fmt(parts(meet-n))}
tick();setInterval(tick,1000);
const tot=2383*60+14;$('calls').innerHTML=`<b>${Math.floor(tot/3600)}</b> ore <b>${Math.floor(tot%3600/60)}</b> min <b>${tot%60}</b> sec`;
$('open').onclick=()=>show('alb');$('back').onclick=()=>show('stats');
const G={lon:-5.6611,lat:43.5322},R={lon:12.4964,lat:41.9028};
const rad=x=>x*Math.PI/180;
const dist=Math.round(2*6371*Math.asin(Math.sqrt(Math.sin(rad(R.lat-G.lat)/2)**2+Math.cos(rad(G.lat))*Math.cos(rad(R.lat))*Math.sin(rad(R.lon-G.lon)/2)**2)));
$('km').innerHTML=`${dist.toLocaleString('it-IT')} km di distanza<small>ma più vicini che mai ♥</small>`;
const cx=$('map').getContext('2d'),W=140,H=100;
const pr=(lo,la)=>[(lo+12)/38*W,(62-la)/28*H];
const land=[
[[-9,43],[-8,37],[-5.5,36],[-1,37.5],[0,39],[3,42],[6,43],[8,44],[10,44],[12.5,42],[16,38],[18,40],[14,42.5],[12.5,44.5],[13.5,45.5],[16,43],[19,41],[21,38],[23,36.5],[26,40],[28,41],[26,45],[26,55],[20,55],[14,54],[10,55],[8,54],[4,52],[2,51],[-2,48.5],[-4.5,48.5],[-1.5,46],[-1.5,43.5],[-9,43.5]],
[[-5,50],[1.5,51],[1.5,53],[-1,55],[-2,57.5],[-5,58],[-6,56],[-3,54.5],[-5,52]],
[[-10,52],[-6,52],[-6,55],[-10,54]],
[[5,59],[11,59],[12,56],[18,57],[19,60],[18,62],[5,62]],
[[8.5,39],[9.5,39],[9.5,41],[8.5,41]]];
const A=pr(G.lon,G.lat),B=pr(R.lon,R.lat),C=[(A[0]+B[0])/2,Math.min(A[1],B[1])-32];
const q=t=>[(1-t)**2*A[0]+2*(1-t)*t*C[0]+t*t*B[0],(1-t)**2*A[1]+2*(1-t)*t*C[1]+t*t*B[1]];
function draw(t){cx.fillStyle='#d8f0ff';cx.fillRect(0,0,W,H);
 land.forEach(p=>{cx.beginPath();p.forEach((v,i)=>{const[x,y]=pr(v[0],v[1]);i?cx.lineTo(x,y):cx.moveTo(x,y)});cx.closePath();cx.fillStyle='#cbb3f7';cx.fill();cx.strokeStyle='#5b3a99';cx.lineWidth=1;cx.stroke()});
 cx.fillStyle='#ff5fa8';for(let i=0;i<=40;i+=2){const[x,y]=q(i/40);cx.fillRect(Math.round(x),Math.round(y),2,2)}
 [A,B].forEach(p=>{cx.fillStyle='#5b3a99';cx.fillRect(Math.round(p[0])-2,Math.round(p[1])-2,5,5)});
 const[x,y]=q(t),h=Math.round(x),v=Math.round(y);cx.fillStyle='#ff5fa8';cx.fillRect(h-3,v-4,3,2);cx.fillRect(h+1,v-4,3,2);cx.fillRect(h-3,v-2,7,2);cx.fillRect(h-1,v,3,2);cx.fillRect(h,v+2,1,1);
 cx.fillStyle='#3d2670';cx.font='7px monospace';cx.fillText('Gijón',A[0]-8,A[1]+11);cx.fillText('Roma',B[0]-8,B[1]+11)}
(function loop(ts){draw((ts/4000)%1);requestAnimationFrame(loop)})(0);
// ALBUM: metti le foto nella cartella "images" e modifica questa lista (nome file + didascalia)
const FOTO=[
 {src:'images/foto1.jpg',cap:'il nostro inizio'},
 {src:'images/foto2.jpg',cap:'4 settembre'},
 {src:'images/foto3.jpg',cap:'prima chiamata'},
 {src:'images/foto4.jpg',cap:'tu e io'},
 {src:'images/foto5.jpg',cap:'pixel love'},
 {src:'images/foto6.jpg',cap:'mi manchi'},
 {src:'images/foto7.jpg',cap:'31 ottobre!'},
 {src:'images/foto8.jpg',cap:'a presto ♥'}
];
FOTO.forEach(f=>{const p=document.createElement('div');p.className='pol';
 p.innerHTML=`<div class="im">${pix('heart',8)}</div><p>${f.cap}</p>`;
 const im=p.querySelector('.im'),t=new Image();
 t.onload=()=>{im.innerHTML='';im.style.backgroundImage=`url("${f.src}")`};
 t.src=f.src;
 $('track').appendChild(p)});
const rp=$('rope');let dn=false,sx=0,sl=0;
rp.onpointerdown=e=>{dn=true;sx=e.clientX;sl=rp.scrollLeft;rp.style.cursor='grabbing'};
addEventListener('pointerup',()=>{dn=false;rp.style.cursor='grab'});
addEventListener('pointermove',e=>{if(dn)rp.scrollLeft=sl-(e.clientX-sx)});